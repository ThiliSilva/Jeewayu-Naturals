<?php

@include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>about</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'header.php'; ?>

<section class="about">

   <div class="row">

      <div class="box">
         <img src="images/ayur-removebg-preview.png" alt=""><br><br><br><br>
         <h3>Why choose us?</h3>
         <p>We are one of the most admired herbal and ayurvedic medicine and cosmetic brands in the country, by leading the modernization of traditional ayurveda through innovation and pioneering research, while offering ,safe and reliable products.</p>
         <a href="contact.php" class="btn">Contact us</a>
      </div>

      <div class="box">
         <img src="images/ayur1.png" alt=""><br><br><br><br>
         <h3>Our mission</h3>
         <p>We dedicate ourselves to humanity's quest for longer, happier, and healthier lives through the innovation and modernization of herbal and ayurvedic medicine and cosmetics, and by ensuring that all our products meet the highest quality standards.</p>
         <a href="shop.php" class="btn">Our Shop</a>
      </div>

   </div>

</section>

<section class="reviews">

   <h1 class="title">Customer reviews</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/pic-1.png" alt="">
         <p>Love this ayurvedic herbal hair oil and hair cream.</p><br><br><br><br><br></br><br><br>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Bethmin De Silva</h3>
		 
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>Love this ayurvedic herbal hair oil! I have tried different hair oils, but have not been fully satisfied with any of them. However, after trying this one, I can tell that I'll be using this in the long run.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Shamen Walker</h3>
      </div>

      <div class="box">
         <img src="images/pic-4.png" alt="">
         <p>I purchased this hair oil. Can definitely recommend as a very good product and a service.</p><br><br><br><br><br>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Amali Gunasekara</h3>
      </div>

      <div class="box">
         <img src="images/pic-3.png" alt="">
         <p>Highly recommended for men also. Best product I've ever used, results were amazing. Thank you for your amazing products.</p>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Lakmal Perera</h3>
      </div>

      <div class="box">
         <img src="images/pic-6.png" alt="">
         <p>Once I apply Jeeweayu Naturals, it makes my hair so refreshing and gives it a shinier look.               </p><br><br><br>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Tirani Danthanarayana</h3>
      </div>

      <div class="box">
         <img src="images/pic-2.png" alt="">
         <p>A very good product, I'm highly satisfied with their hair oil.</p><br><br><br><br><br><br>
         <div class="stars">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star-half-alt"></i>
         </div>
         <h3>Pabasara Jayakody</h3>
      </div>

   </div>

</section>
<?php include 'footer.php'; ?>

<script src="js/script.js"></script>

</body>
</html>