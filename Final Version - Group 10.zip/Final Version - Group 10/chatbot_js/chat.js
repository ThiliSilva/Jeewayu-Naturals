// JavaScript Document
function getHardResponse(userText) {
    let botResponse = getBotResponse(userText);
    let botHtml = '<p class="botText"><span>' + botResponse + '</span></p>';
    $("#typeInputUi").append(botHtml);

    document.getElementById("chat-bar-bottom").scrollIntoView(true);
}