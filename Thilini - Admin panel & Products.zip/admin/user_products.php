<?php

@include 'db.php';

if(isset($_POST['add_to_cart'])){

  // $product_pid = $_POST['product_id'];
   $product_name = $_POST['product_name'];
   $discount_price = $_POST['discount_price'];
   $p_qty = $_POST['p_qty'];
   $product_image = $_POST['product_image'];
	
   $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE name = ?");
   $check_cart_numbers->execute([$product_name, $user_id]);

   if($check_cart_numbers->rowCount() > 0){
      $message[] = 'Already added to cart!';
   }else{

      $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, name, price, quantity, image) VALUES(?,?,?,?,?)");
      $insert_cart->execute([$user_id, $product_name, $discount_price, $p_qty, $product_image]);
      $message[] = 'Product added to cart';
   }

   //$select_cart = mysqli_query($conn, "SELECT * FROM `cart` WHERE name = '$product_name'");

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Jeewayu natural | products</title>

      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
   <link rel="stylesheet" href="css/Stylesheet.css">
</head>
<body>
   
<?php

if(isset($message)){
   foreach($message as $message){
      echo '<div class="message"><span>'.$message.'</span> <i class="fas fa-times" onclick="this.parentElement.style.display = `none`;"></i> </div>';
   };
};

?>
	
<div class="slideshow-container" align="center">
  <div class="slides fade">
    <img src="images/skin2.jpg" alt="1" width="1050" height="450" style="width:1500">
  </div>

  <div class="slides fade">
    <img src="images/skin3.jpg" alt="2" width="1050" height="450" style="width:1000">
  </div>

  <div class="slides fade">
    <img src="images/skin1.jpg" alt="3" width="1050" height="450" style="width:800">
  </div>
	<div class="slides fade">
    <img src="images/skin4.jpg" alt="4" width="1050" height="450" style="width:1000">
  </div>
	<div class="slides fade">
    <img src="images/hair1.jpg" alt="4" width="1050" height="450" style="width:1000">
  </div>
	<div class="slides fade">
    <img src="images/hair2.jpg" alt="4" width="1050" height="450" style="width:1000">
  </div>
</div>


<div class="container">

<section class="products">

   <h3 class="title">All Products</h3>

   <div class="products-container">

      <?php
      
      $select_products = mysqli_query($conn, "SELECT * FROM `products`");
      if(mysqli_num_rows($select_products) > 0){
         while($fetch_product = mysqli_fetch_assoc($select_products)){
      ?>

      <form action="" method="post">
         <div class="product"><p><?php echo $fetch_product['availability']; ?></p>
            <img src="uploaded_img/<?php echo $fetch_product['image']; ?>" alt="">
            <h3><?php echo $fetch_product['name']; ?></h3>  
			
			 <h2>Rs. <?php echo $fetch_product['price']; ?>.00 </h2> 
			 <h>Rs. <?php echo $fetch_product['discount']; ?>.00</h><br>
			 <input type="number" min="1" value="1" name="p_qty" class="qty"> <br>
            <input type="hidden" name="product_name" value="<?php echo $fetch_product['name']; ?>">
			  <input type="hidden" name="product_price" value="<?php echo $fetch_product['price']; ?>">
			 <input type="hidden" name="discount_price" value="<?php echo $fetch_product['discount']; ?>">
			  <input type="hidden" name="availability" value="<?php echo $fetch_product['availability']; ?>">
            <input type="hidden" name="product_image" value="<?php echo $fetch_product['image']; ?>"><br>
			 
			  <div class="buttons">
               <a href="" class="cart" name="add_to_cart" >add to cart</a>
		  </div>
         </div>
      </form>

      <?php
         };
      };
      ?>

   </div>

</section>

</div>

<script>
	
var slideIndex = 0;
	showSlides();
function showSlides() {
  var i;
  var slides = document.getElementsByClassName("slides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides,2000 ); 
}

</script>

</body>
</html>