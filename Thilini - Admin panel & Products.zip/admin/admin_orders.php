<?php

@include 'db.php';

//session_start();

//$admin_id = $_SESSION['admin_id'];

//if(!isset($admin_id)){
//   header('location:login.php');
//};

if(isset($_POST['update_order'])){
   $order_id = $_POST['order_id'];
   $update_payment = $_POST['update_payment'];
   
	$update_orders = mysqli_query($conn, "UPDATE `orders` SET payment_status = '$update_payment' WHERE order_id = '$order_id'");

   if($update_orders){
       $message[] = 'Payment has been updated';
	   header('location:admin_orders.php');
   }else{
      $message[] = 'Update failed!';
      header('location:admin_orders.php');
   }

};

if(isset($_GET['delete'])){

   $delete_id = $_GET['delete'];
   $delete_orders=mysqli_query($conn, "DELETE FROM orders WHERE order_id = $delete_id");
	
	if($delete_query){
      $message[] = 'Order deleted succesfully';
	   header('location:admin_orders.php');
   }else{
      $message[] = 'Delete failed!';
      header('location:admin_orders.php');
   }

}

  
	


?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>orders</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">
	<link rel="stylesheet" href="css/style.css">
	

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<section class="placed-orders">

   <h1 class="title">placed orders</h1>

   <div class="box-container">

      <?php
        $select_orders = mysqli_query($conn, "SELECT * FROM `orders`");
	   
	   if(mysqli_num_rows($select_orders) > 0){
         while($fetch_orders = mysqli_fetch_assoc($select_orders)){
			 
      ?>
      <div class="box">
         <p> user id : <span><?= $fetch_orders['user_id']; ?></span> </p>
         <p> placed on : <span><?= $fetch_orders['placed_on']; ?></span> </p>
         <p> name : <span><?= $fetch_orders['name']; ?></span> </p>
         <p> email : <span><?= $fetch_orders['email']; ?></span> </p>
         <p> number : <span><?= $fetch_orders['number']; ?></span> </p>
         <p> address : <span><?= $fetch_orders['address']; ?></span> </p>
         <p> total products : <span><?= $fetch_orders['total_products']; ?></span> </p>
         <p> total price : <span>Rs. <?= $fetch_orders['total_price']; ?>.00</span> </p> 
 
         <form action="" method="POST">
            <input type="hidden" name="order_id" value="<?= $fetch_orders['order_id']; ?>">
            <select name="update_payment" class="drop-down">
               <option value="" selected disabled><?= $fetch_orders['payment_status']; ?></option>
               <option value="Pending">Pending</option>
               <option value="Completed">Completed</option>
            </select>
			 
			 <div class="flex-btn">
               <input type="submit" name="update_order" class="btn" value="update">
               <a href="admin_orders.php?delete=<?= $fetch_orders['order_id']; ?>" class="btn" onclick="return confirm('Are you want to delete this?');">delete</a>
			 </div>		
			
           
         </form>
      </div>
      <?php
         }
		}else{
         echo '<p class="empty">no orders placed yet!</p>';
      }
      
      ?>

   </div>

</section>












<script src="js/script.js"></script>

</body>
</html>