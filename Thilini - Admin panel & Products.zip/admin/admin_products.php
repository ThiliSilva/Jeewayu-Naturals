<?php

@include 'db.php';

if(isset($_POST['add_product'])){

   $product_name = $_POST['product_name'];
   $product_price = $_POST['product_price'];
   $discount_price = $_POST['discount_price'];
   $cat = $_POST['cat'];
	$stock = $_POST['availability'];
   $product_image = $_FILES['product_image']['name'];
   $product_image_tmp_name = $_FILES['product_image']['tmp_name'];
   $product_image_folder = 'uploaded_img/'.$product_image;

      $insert = "INSERT INTO products(name, price, discount, category, availability, image) VALUES('$product_name', '$product_price', '$discount_price', '$cat', '$stock', '$product_image')";
      $upload = mysqli_query($conn,$insert);
      if($upload){
         move_uploaded_file($product_image_tmp_name, $product_image_folder);
         $message[] = 'Product added successfully';
      }else{
         $message[] = 'Added failed!';
      }

};

if(isset($_GET['delete'])){
   $id = $_GET['delete'];
   $delete_query=mysqli_query($conn, "DELETE FROM products WHERE id = $id");
	if($delete_query){
      $message[] = 'Product deleted succesfully';
	   header('location:admin_products.php');
   }else{
      $message[] = 'Delete failed!';
      header('location:admin_products.php');
   }

};

if(isset($_POST['update_product'])){
   $update_p_id = $_POST['update_p_id'];
   $update_p_name = $_POST['update_p_name'];
   $update_p_price = $_POST['update_p_price'];
   $update_d_price = $_POST['update_d_price'];
	$update_cat = $_POST['update_cat'];
	$update_stock = $_POST['update_stock'];
   $update_p_image = $_FILES['update_p_image']['name'];
   $update_p_image_tmp_name = $_FILES['update_p_image']['tmp_name'];
   $update_p_image_folder = 'uploaded_img/'.$update_p_image;

   $update_query = mysqli_query($conn, "UPDATE `products` SET name = '$update_p_name', price = '$update_p_price', discount = '$update_d_price', category = '$update_cat', availability = '$update_stock', image = '$update_p_image' WHERE id = '$update_p_id'");

   if($update_query){
      move_uploaded_file($update_p_image_tmp_name, $update_p_image_folder);
      $message[] = 'Product updated succesfully';
	   header('location:admin_products.php');
   }else{
      $message[] = 'Update failed!';
      header('location:admin_products.php');
   }

};

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Jeewayu Naturals | Admin_products</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/admin_style.css">

</head>
<body>
	<?php include 'admin_header.php'; ?><br><br>
	<h1 class="title">products</h1>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<span class="message">'.$message.'</span>';
   }
}

?>
   
<div class="container">

   <div class="admin-product-form-container">

      <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
         <h3>add a new product</h3>
         <input type="text" placeholder="Enter product name" name="product_name" class="box" required >
         <input type="number" placeholder="Enter old price" name="product_price" class="box" >
		   <input type="number" placeholder="Enter new price" name="discount_price" class="box"  >
		  <select name="cat" id="cat" class="box" required>
	      <option value="Skin Care">Skin Care</option>
	      <option value="Hair Care">Hair Care</option>
		  <option value="Oral Care">Oral Care</option>
        </select>
		  
		  <select name="availability" id="availability" class="box" required>
	      <option value="In Stock">In Stock</option>
	      <option value="Out of Stock">Out of Stock</option>
        </select>
         <input type="file" accept="image/png, image/jpeg, image/jpg" name="product_image" class="box" required >
         <input type="submit" class="btn" name="add_product" value="add product">
		  
      </form>

   </div>

   <?php
	
      $select = mysqli_query($conn, "SELECT * FROM products");
   
   ?>
   <div class="product-display" >
      <table class="product-display-table">
         <thead>
         <tr>
            <th>product image</th>
            <th>product name</th>
			 <th>category</th>
			 <th>availability</th>
            <th>old price</th>
			 <th>new price</th>
            <th>action</th>
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="100" alt=""></td>
            <td><?php echo $row['name']; ?></td>
			 <td><?php echo $row['category']; ?></td>
			  <td><?php echo $row['availability']; ?></td>
            <td><h>Rs. <?php echo $row['price']; ?></td></h>
			 <td>Rs. <?php echo $row['discount']; ?></td>
            <td>
			   <a href="admin_products.php?edit=<?php echo $row['id']; ?>" class="btn"> <i class="fas fa-edit"></i> edit </a><br>
               <a href="admin_products.php?delete=<?php echo $row['id']; ?>" class="btn" onclick="return confirm('Are you want to delete this?');"> <i class="fas fa-trash"></i> delete </a>
            </td>
         </tr>
      <?php } ?>
      </table>
   </div>

	
</section>

<section class="edit-form-container">

   <?php
   
   if(isset($_GET['edit'])){
      $edit_id = $_GET['edit'];
      $edit_query = mysqli_query($conn, "SELECT * FROM `products` WHERE id = $edit_id");
      if(mysqli_num_rows($edit_query) > 0){
         while($fetch_edit = mysqli_fetch_assoc($edit_query)){
   ?>

   <form action="" method="post" enctype="multipart/form-data">
      <img src="uploaded_img/<?php echo $fetch_edit['image']; ?>" height="200" alt="">
      <input type="hidden" name="update_p_id" value="<?php echo $fetch_edit['id']; ?>">
      <input type="text" class="box" name="update_p_name" value="<?php echo $fetch_edit['name']; ?>">
      <input type="text" class="box" name="update_p_price" value="<?php echo $fetch_edit['price']; ?>">
	  <input type="text" class="box" name="update_d_price" value="<?php echo $fetch_edit['discount']; ?>">
	  
	   <select name="update_cat" id="cat" class="box" required>
	      <option value="Skin Care">Skin Care</option>
	      <option value="Hair Care">Hair Care</option>
		  <option value="Oral Care">Oral Care</option>
        </select>
	   
	   <select name="update_stock" id="availability" class="box" required>
	      <option value="In Stock">In Stock</option>
	      <option value="Out of Stock">Out of Stock</option>
        </select>
	   
      <input type="file" class="box" required name="update_p_image" accept="image/png, image/jpg, image/jpeg">
      <input type="submit" value="Update" name="update_product" class="btn"><br>
      <input type="reset" value="Go Back" id="close-edit" class="btn">
   </form>
	
	<?php 
		 };
	  };
	   echo "<script>document.querySelector('.edit-form-container').style.display = 'flex';</script>";
   }

	   ?>
	
</section>

</div>
	
	<script>
	document.querySelector('#close-edit').onclick = () =>{
   document.querySelector('.edit-form-container').style.display = 'none';
   window.location.href = 'admin_products.php';
};
		
	
	</script>


</body>
</html>