<?php

@include 'db.php';

//session_start();

//$admin_id = $_SESSION['admin_id'];

//if(!isset($admin_id)){
   //header('location:login.php');
//}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Jeewayu Naturals | Admin_panel</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/admin_style.css">
	<link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'admin_header.php'; ?>

<section class="dashboard">

   <h1 class="title">Dashboard</h1>

   <div class="box-container">

      <div class="box">
      <?php
         $total_pendings = 0;
		  $select_pendings=mysqli_query($conn, "SELECT * FROM `orders` WHERE payment_status = 'Pending'");
			 $total_pendings = mysqli_num_rows($select_pendings);
      ?>
      <h3><?= $total_pendings; ?></h3>
      <p>Pending Orders</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>

      <div class="box">
      <?php
         $total_completed = 0;
		  $select_completed=mysqli_query($conn, "SELECT * FROM `orders` WHERE payment_status = 'Completed'");
		   $total_completed = mysqli_num_rows($select_completed);
		
      ?>
      <h3><?= $total_completed; ?></h3>
      <p>Completed Orders</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>
	   
	   

      <div class="box">
      <?php
		 $select_orders=mysqli_query($conn, "SELECT * FROM `orders`");
         $number_of_orders = mysqli_num_rows($select_orders);
      ?>
      <h3><?= $number_of_orders; ?></h3>
      <p>Available Orders</p>
      <a href="admin_orders.php" class="btn">see orders</a>
      </div>

	   
	   
      <div class="box">
      <?php
		  $select_products=mysqli_query($conn, "SELECT * FROM `products`");
		  $number_of_products = mysqli_num_rows($select_products);
      ?>
      <h3><?= $number_of_products; ?></h3>
      <p>Available Products</p>
      <a href="admin_products.php" class="btn">see products</a>
      </div>
	   
	      

      <div class="box">
      <?php
		  $number_of_users = 0;
		 $select_users=mysqli_query($conn, "SELECT * FROM `users` WHERE user_type = 'admin'"); 
		  $number_of_users = mysqli_num_rows($select_users);	

      ?>
      <h3><?= $number_of_users; ?></h3>
      <p>Total Users</p>
      <a href="admin_users.php" class="btn">see accounts</a>
      </div>
	   
	   

      <div class="box">
      <?php
		   $number_of_admins = 0;
		  $select_admins=mysqli_query($conn, "SELECT * FROM `users` WHERE user_type = 'admin'"); 
		    $number_of_admins = mysqli_num_rows($select_admins);
      ?>
      <h3><?= $number_of_admins; ?></h3>
      <p>Total Admins</p>
      <a href="admin_users.php" class="btn">see accounts</a>
      </div>

	   
	   
      <div class="box">
      <?php
         $select_accounts = mysqli_query($conn, "SELECT * FROM `users`");
		 $number_of_accounts = mysqli_num_rows($select_accounts);
      ?>
      <h3><?= $number_of_accounts; ?></h3>
      <p>Total Accounts</p>
      <a href="admin_users.php" class="btn">see accounts</a>
      </div>


   </div>

</section>













<script src="js/script.js"></script>

</body>
</html>